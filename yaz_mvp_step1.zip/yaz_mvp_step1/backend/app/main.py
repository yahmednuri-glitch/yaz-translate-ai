from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent
STORAGE = BASE_DIR / "storage"
UPLOADS = STORAGE / "uploads"
OUTPUTS = STORAGE / "outputs"
UPLOADS.mkdir(parents=True, exist_ok=True)
OUTPUTS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="YAZ Translate AI MVP")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PROJECTS: dict[str, dict] = {}

class ProcessRequest(BaseModel):
    source_language: str = "en"
    target_language: str = "ar"

@app.get("/health")
def health():
    return {"ok": True, "service": "YAZ Translate AI Backend"}

@app.post("/api/projects")
async def create_project(file: UploadFile = File(...)):
    if not file.content_type or not file.content_type.startswith("video/"):
        raise HTTPException(status_code=400, detail="ارفع ملف فيديو فقط")

    project_id = str(uuid4())
    safe_name = file.filename or "video.mp4"
    saved_path = UPLOADS / f"{project_id}_{safe_name}"
    with saved_path.open("wb") as f:
        while chunk := await file.read(1024 * 1024):
            f.write(chunk)

    PROJECTS[project_id] = {
        "id": project_id,
        "title": safe_name,
        "status": "uploaded",
        "source_language": None,
        "target_language": None,
        "video_path": str(saved_path),
        "transcript": "",
        "translation": "",
        "srt_path": None,
    }
    return PROJECTS[project_id]

@app.get("/api/projects")
def list_projects():
    return list(PROJECTS.values())

@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    project = PROJECTS.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return project

@app.post("/api/projects/{project_id}/process")
def process_project(project_id: str, payload: ProcessRequest):
    project = PROJECTS.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")

    # Mock processing for Step 1. Replace this in Step 2 with FFmpeg + Whisper + translation.
    transcript = "Hello, welcome to YAZ Translate AI. This is the first working test."
    translation = "مرحبًا، أهلاً بك في YAZ Translate AI. هذا أول اختبار يعمل بنجاح."
    srt_content = """1\n00:00:00,000 --> 00:00:03,000\nمرحبًا، أهلاً بك في YAZ Translate AI.\n\n2\n00:00:03,000 --> 00:00:06,000\nهذا أول اختبار يعمل بنجاح.\n"""
    srt_path = OUTPUTS / f"{project_id}.srt"
    srt_path.write_text(srt_content, encoding="utf-8")

    project.update({
        "status": "processed",
        "source_language": payload.source_language,
        "target_language": payload.target_language,
        "transcript": transcript,
        "translation": translation,
        "srt_path": str(srt_path),
    })
    return project

@app.get("/api/projects/{project_id}/subtitle")
def download_subtitle(project_id: str):
    project = PROJECTS.get(project_id)
    if not project or not project.get("srt_path"):
        raise HTTPException(status_code=404, detail="ملف الترجمة غير جاهز")
    return FileResponse(project["srt_path"], media_type="application/x-subrip", filename="yaz_translation.srt")
